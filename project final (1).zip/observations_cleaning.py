import pandas as pd
import psycopg2


CSV_PATH = r"D:\Assignments\Data Engineering\project\data\observations.csv"
DB_CONFIG = {
    "host": "localhost",
    "port": "5432",
    "dbname": "postgres",
    "user": "postgres",
    "password": "1234"
}

with open(CSV_PATH, 'r', encoding='utf-8') as f:
    lines = f.readlines()


fixed_header = lines[0].strip().strip('"').split('","')


df = pd.read_csv(
    CSV_PATH,
    sep=",",
    skiprows=1,      
    header=None,     
    names=fixed_header,
    dtype=str        
)

print(f"Total rows read from CSV: {len(df)}")


def parse_iso(dt_str):
    for fmt in ("%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S"):
        try:
            return pd.to_datetime(dt_str, format=fmt)
        except:
            continue
    return pd.NaT

df['observation_datetime'] = df['observation_datetime'].apply(parse_iso)


bad = df['observation_datetime'].isna().sum()
if bad:
    print(f"Dropping {bad} rows with invalid datetimes")
df = df.dropna(subset=['observation_datetime'])


df['observation_datetime'] = df['observation_datetime'].dt.floor('s')

print(f"Rows after datetime cleaning: {len(df)}")


conn = psycopg2.connect(**DB_CONFIG)
cur = conn.cursor()


cur.execute("""
CREATE TABLE IF NOT EXISTS observations (
    encounter_id UUID,
    observation_code TEXT,
    observation_datetime TIMESTAMP,
    observation_description TEXT,
    observation_id UUID PRIMARY KEY,
    patient_id UUID,
    units TEXT,
    value_numeric FLOAT,
    value_text TEXT
);
""")
conn.commit()


inserted = 0
for _, row in df.iterrows():
    cur.execute("""
        INSERT INTO observations (
            encounter_id, observation_code, observation_datetime,
            observation_description, observation_id, patient_id,
            units, value_numeric, value_text
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (observation_id) DO NOTHING;
    """, (
        row['encounter_id'],
        row['observation_code'],
        row['observation_datetime'],
        row['observation_description'],
        row['observation_id'],
        row['patient_id'],
        row['units']      or None,
        float(row['value_numeric']) if row['value_numeric']!='' else None,
        row['value_text'] or None
    ))
    inserted += 1

conn.commit()
cur.close()
conn.close()

print(f"Inserted {inserted} rows into observations.")