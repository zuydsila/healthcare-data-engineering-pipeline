import pandas as pd
import psycopg2
from io import StringIO

csv_data = r"D:\Assignments\Data Engineering\project\data\patients.csv"

df = pd.read_csv(csv_data)
print(df.columns.tolist())

df['phone_number'] = df['phone_number'].apply(
    lambda x: "Unknown" if isinstance(x, str) and x.strip().startswith('-') else x
)

conn = psycopg2.connect(
    host="localhost",
    port="5432",
    dbname="postgres",
    user="postgres",
    password="1234"
)
cur = conn.cursor()
create_table_query = """
CREATE TABLE IF NOT EXISTS patients (
    address TEXT,
    city TEXT,
    date_of_birth DATE,
    first_name TEXT,
    gender TEXT,
    last_name TEXT,
    patient_id UUID PRIMARY KEY,
    phone_number TEXT,
    state TEXT,
    zip_code TEXT
);
"""
cur.execute(create_table_query)
conn.commit()


for _, row in df.iterrows():
    cur.execute("""
        INSERT INTO patients (
            address, city, date_of_birth, first_name, gender, last_name,
            patient_id, phone_number, state, zip_code
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (patient_id) DO NOTHING;
    """, (
        row['address'], row['city'], row['date_of_birth'], row['first_name'], row['gender'],
        row['last_name'], row['patient_id'], row['phone_number'], row['state'], str(row['zip_code'])
    ))


conn.commit()
cur.close()
conn.close()

print("Data loaded into PostgreSQL successfully.")
