import json
import pandas as pd
import psycopg2

JSON_PATH = r"D:\Assignments\Data Engineering\project\data\diagnoses.json"
DB_CONFIG = {
    "host":     "localhost",
    "port":     "5432",
    "dbname":   "postgres",
    "user":     "postgres",
    "password": "1234"
}

with open(JSON_PATH, 'r', encoding='utf-8') as f:
    data = json.load(f)

df = pd.json_normalize(data)
print(f"Total records in JSON: {len(df)}")

def parse_iso(dt_str):
    for fmt in ("%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S"):
        try:
            return pd.to_datetime(dt_str, format=fmt)
        except:
            continue
    return pd.NaT

df['date_recorded'] = df['date_recorded'].apply(parse_iso)
bad = df['date_recorded'].isna().sum()
if bad:
    print(f"Dropping {bad} rows with invalid date_recorded")
df = df.dropna(subset=['date_recorded'])
df['date_recorded'] = df['date_recorded'].dt.floor('s')
print(f"Records after date cleaning: {len(df)}")
 

conn = psycopg2.connect(**DB_CONFIG)
cur = conn.cursor()
  

cur.execute("""
CREATE TABLE IF NOT EXISTS diagnoses (
    diagnosis_id          UUID PRIMARY KEY,
    encounter_id          UUID,
    patient_id            UUID,
    diagnosis_code        TEXT,
    diagnosis_description TEXT,
    date_recorded         TIMESTAMP
);
""")
conn.commit()


inserted = 0
for _, row in df.iterrows():
    cur.execute("""
        INSERT INTO diagnoses (
            diagnosis_id,
            encounter_id,
            patient_id,
            diagnosis_code,
            diagnosis_description,
            date_recorded
        ) VALUES (%s, %s, %s, %s, %s, %s)
        ON CONFLICT (diagnosis_id) DO NOTHING;
    """, (
        row['diagnosis_id'],
        row['encounter_id'],
        row['patient_id'],
        row['diagnosis_code'],
        row['diagnosis_description'],
        row['date_recorded']
    ))
    inserted += 1

conn.commit()
cur.close()
conn.close()

print(f"Inserted {inserted} rows into diagnoses.")
