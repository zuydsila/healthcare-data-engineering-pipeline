import pandas as pd
import sqlite3
import psycopg2



SQLITE_PATH = r"D:\Assignments\Data Engineering\project\data\ehr_journeys_database.sqlite"
PG_CONFIG   = {
    "host":     "localhost",
    "port":     "5432",
    "dbname":   "postgres",
    "user":     "postgres",
    "password": "1234"
}


sqlite_conn = sqlite3.connect(SQLITE_PATH)
df = pd.read_sql_query("SELECT * FROM encounters;", sqlite_conn)
sqlite_conn.close()
print(f"Loaded {len(df)} rows from SQLite `encounters`")



for col in ["admission_date", "discharge_date"]:
    df[col] = df[col].astype(str).str.replace(r"\.\d+", "", regex=True)


for col in ["admission_date", "discharge_date"]:
    df[col] = pd.to_datetime(df[col], format="%Y-%m-%dT%H:%M:%S", errors="coerce")


bad = df[["admission_date", "discharge_date"]].isna().any(axis=1).sum()
if bad:
    print(f"Dropping {bad} rows with invalid dates after stripping ms")
    df = df.dropna(subset=["admission_date", "discharge_date"])
print(f"{len(df)} rows remain after date cleaning")


pg_conn = psycopg2.connect(**PG_CONFIG)
cur     = pg_conn.cursor()


cur.execute("""
CREATE TABLE IF NOT EXISTS encounters (
    encounter_id           UUID PRIMARY KEY,
    patient_id             UUID,
    admission_date         TIMESTAMP,
    attending_physician_id TEXT,
    discharge_date         TIMESTAMP,
    visit_type             TEXT
);
""")
pg_conn.commit()

inserted = 0
for _, row in df.iterrows():
    cur.execute("""
        INSERT INTO encounters (
            encounter_id,
            patient_id,
            admission_date,
            attending_physician_id,
            discharge_date,
            visit_type
        ) VALUES (%s, %s, %s, %s, %s, %s)
        ON CONFLICT (encounter_id) DO NOTHING;
    """, (
        row["encounter_id"],
        row["patient_id"],
        row["admission_date"],
        row["attending_physician_id"],
        row["discharge_date"],
        row["visit_type"]
    ))
    inserted += 1

pg_conn.commit()
cur.close()
pg_conn.close()

print(f" Inserted {inserted} rows into PostgreSQL `encounters`")
