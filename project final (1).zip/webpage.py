from flask import Flask, request, redirect, render_template_string, session, url_for
from datetime import datetime, time
import logging
import psycopg2
import os
import psutil
import time as time_module

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(BASE_DIR, 'login.log')

app = Flask(__name__)
app.secret_key = 'secret_key'

# Business hours
BUSINESS_START = time(9, 0)
BUSINESS_END = time(23, 0)

# Auth
USER_CREDENTIALS = {'admin': '123'}

# PostgreSQL config
DB_CONFIG = {
    'host': 'localhost',
    'port': 5432,
    'dbname': 'data',
    'user': 'postgres',
    'password': '1234'
}

#setup logger
logger = logging.getLogger('login_logger')
logger.setLevel(logging.INFO)
file_handler = logging.FileHandler(LOG_PATH)
formatter = logging.Formatter('%(asctime)s - %(message)s')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)


STYLE = '''
<style>
    body { font-family: Arial; background: #f4f7fa; padding: 20px; }
    .container { max-width: 950px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #ccc; position: relative; }
    h2, h3 { color: #333; }
    input, select, textarea, button {
        font-size: 14px; margin: 5px 0; padding: 10px; width: 100%;
        border: 1px solid #ccc; border-radius: 4px;
    }
    input[type=submit], button {
        background-color: #4CAF50; color: white; cursor: pointer;
        width: auto;
    }
    button:hover, input[type=submit]:hover {
        background-color: #45a049;
    }
    table { width: 100%; border-collapse: collapse; margin-top: 15px; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: left; font-size: 14px; }
    th { background-color: #f2f2f2; }
    .error { color: red; }
    .logout {
        position: absolute;
        top: 20px;
        right: 20px;
        background-color: #d9534f;
        border: none;
        color: white;
        padding: 8px 15px;
        font-size: 14px;
        border-radius: 4px;
        cursor: pointer;
        width: auto;
    }
    .logout:hover {
        background-color: #c9302c;
    }
    .perf-checkbox {
        position: fixed;
        top: 20px;
        left: 20px;
        background: white;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-shadow: 0 0 5px #aaa;
        z-index: 9999;
    }
</style>
'''

LOGIN_TEMPLATE = STYLE + '''
<div class="container">
    <h2>Login</h2>
    {% if error %}<p class="error">{{ error }}</p>{% endif %}
    <form method="post">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="submit" value="Login">
    </form>
</div>
'''

DASHBOARD_TEMPLATE = STYLE + '''
<div class="perf-checkbox">
    <form method="post" id="perfFormTop">
        <label><input type="checkbox" name="show_perf" value="on" {% if show_perf %}checked{% endif %} onchange="document.getElementById('perfFormTop').submit();"> Show Performance Details</label>
        <!-- Submit triggers reload to keep checkbox state -->
        <input type="hidden" name="action" value="noop">
    </form>
</div>

<div class="container">
    <h2>Doctor’s Medical Dashboard</h2>

    <form method="post" action="{{ url_for('logout') }}">
        <button class="logout" type="submit">Logout</button>
    </form>

    <form method="post">
        <h3>Search Patient</h3>
        <input type="text" name="search_first" placeholder="First name" value="{{ request.form.get('search_first', '') }}">
        <input type="text" name="search_last" placeholder="Last name" value="{{ request.form.get('search_last', '') }}">
        <input type="date" name="search_dob" placeholder="Date of Birth" value="{{ request.form.get('search_dob', '') }}">
        <!-- Removed local checkbox here -->
        <button type="submit" name="action" value="search_patient">Search</button>
        <input type="hidden" name="show_perf" value="{{ 'on' if show_perf else 'off' }}">
    </form>

    <hr>

    <h3>Quick Doctor Queries</h3>
    <form method="post">
        <!-- Removed local checkbox here -->
        <button type="submit" name="action" value="all_patients">All Patients</button>
        <button type="submit" name="action" value="diagnoses_week">Diagnoses This Week</button>
        <button type="submit" name="action" value="medications_now">Current Medications</button>
        <button type="submit" name="action" value="recent_procedures">Recent Procedures</button>
        <button type="submit" name="action" value="recent_observations">Recent Observations</button>
        <button type="submit" name="action" value="age_stats">Average Age & Age Range</button>
        <button type="submit" name="action" value="avg_patients_per_physician">Average Patients per Physician</button>
        <input type="hidden" name="show_perf" value="{{ 'on' if show_perf else 'off' }}">
    </form>

    <hr>

    <h3>Custom SQL</h3>
    <form method="post">
        <textarea name="query" rows="5" placeholder="SELECT * FROM patients_decrypted;">{{ query|default('') }}</textarea><br>
        <!-- Removed local checkbox here -->
        <button type="submit" name="action" value="custom_query">Run Query</button>
        <input type="hidden" name="show_perf" value="{{ 'on' if show_perf else 'off' }}">
    </form>

    {% if error %}
        <p class="error">{{ error }}</p>
    {% endif %}

    {% for title, headers, rows in results %}
    <h3>{{ title }}</h3>
    <div style="overflow-x:auto;">
        <table style="margin:auto;">
            <tr>{% for col in headers %}<th>{{ col }}</th>{% endfor %}</tr>
            {% for row in rows %}
            <tr>{% for val in row %}<td>{{ val }}</td>{% endfor %}</tr>
            {% endfor %}
        </table>
    </div>
    {% endfor %}
</div>
'''

def is_business_hours():
    now = datetime.now().time()
    return BUSINESS_START <= now <= BUSINESS_END

def log_login(username, success):
    logger.info(f"Login attempt - User: {username}, Success: {success}")

def connect_db():
    return psycopg2.connect(**DB_CONFIG)

@app.route('/', methods=['GET', 'POST'])
def login():
    if 'username' in session:
        return redirect(url_for('db_interface'))

    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if USER_CREDENTIALS.get(username) == password:
            if is_business_hours():
                session['username'] = username
                log_login(username, True)
                return redirect(url_for('db_interface'))
            else:
                error = "Access denied outside business hours."
                log_login(username, False)
        else:
            log_login(username, False)
            error = "Invalid credentials."

    return render_template_string(LOGIN_TEMPLATE, error=error)

@app.route('/db', methods=['GET', 'POST'])
def db_interface():
    if 'username' not in session:
        return redirect(url_for('login'))
    if not is_business_hours():
        return "Access denied outside business hours."

    results = []
    query = ''
    error = None
    process = psutil.Process()

    if request.method == 'POST':
        show_perf = request.form.get('show_perf') == 'on'
    else:
        show_perf = False

    if request.method == 'POST':
        action = request.form.get('action', '')
        search_first = request.form.get('search_first', '').strip()
        search_last = request.form.get('search_last', '').strip()
        search_dob = request.form.get('search_dob', '').strip()
        query = request.form.get('query', '').strip()

        try:
            conn = connect_db()
            cur = conn.cursor()

            def execute_with_perf(sql, params=None):
                ts_start = datetime.now()
                wall_start = time_module.perf_counter()
                mem_before = process.memory_info().rss

                if params:
                    cur.execute(sql, params)
                else:
                    cur.execute(sql)

                data = cur.fetchall()

                ts_end = datetime.now()
                wall_end = time_module.perf_counter()
                mem_after = process.memory_info().rss

                elapsed_wall = wall_end - wall_start
                mem_diff = mem_after - mem_before

                rows_affected = cur.rowcount
                if rows_affected < 0:
                    rows_affected = len(data)

                perf_report = [
                    ("Timestamp Start", ts_start.strftime("%Y-%m-%d %H:%M:%S.%f")),
                    ("Timestamp End", ts_end.strftime("%Y-%m-%d %H:%M:%S.%f")),
                    ("time (seconds)", f"{elapsed_wall:.6f}"),
                    ("Memory usage change (MB)", f"{mem_diff / (1024*1024):.6f}"),
                    ("Rows affected/fetched", str(rows_affected))
                ]

                return data, [desc[0] for desc in cur.description], perf_report

            def execute(sql, params=None):
                if show_perf:
                    return execute_with_perf(sql, params)
                else:
                    if params:
                        cur.execute(sql, params)
                    else:
                        cur.execute(sql)
                    data = cur.fetchall()
                    return data, [desc[0] for desc in cur.description], None

            if action == 'all_patients':
                data, headers, perf = execute(
                    "SELECT patient_id, first_name, last_name, date_of_birth, phone_number FROM patients_decrypted"
                )
                results.append(("All Patients", headers, data))
                if show_perf and perf:
                    results.append(("Performance Report", ["Metric", "Value"], perf))

            elif action == 'diagnoses_week':
                data, headers, perf = execute("""
                    SELECT d.patient_id, pd.first_name, pd.last_name, d.date_recorded, d.diagnosis_description
                    FROM diagnoses d
                    JOIN patients_decrypted pd ON pd.patient_id = d.patient_id
                    WHERE d.date_recorded >= current_date - interval '7 days'
                """)
                results.append(("Diagnoses This Week", headers, data))
                if show_perf and perf:
                    results.append(("Performance Report", ["Metric", "Value"], perf))

            elif action == 'medications_now':
                data, headers, perf = execute("""
                    SELECT m.patient_id, pd.first_name, pd.last_name, m.drug_name, m.start_date, m.end_date
                    FROM medications m
                    JOIN patients_decrypted pd ON pd.patient_id = m.patient_id
                    WHERE m.end_date IS NULL OR m.end_date >= current_date
                """)
                results.append(("Current Medications", headers, data))
                if show_perf and perf:
                    results.append(("Performance Report", ["Metric", "Value"], perf))

            elif action == 'recent_procedures':
                data, headers, perf = execute("""
                    SELECT p.patient_id, pd.first_name, pd.last_name, p.procedure_description, p.date_performed
                    FROM procedures p
                    JOIN patients_decrypted pd ON pd.patient_id = p.patient_id
                    WHERE p.date_performed > current_date - interval '30 days'
                """)
                results.append(("Recent Procedures", headers, data))
                if show_perf and perf:
                    results.append(("Performance Report", ["Metric", "Value"], perf))

            elif action == 'recent_observations':
                data, headers, perf = execute("""
                    SELECT o.patient_id, pd.first_name, pd.last_name, o.observation_description, o.value_text, o.value_numeric, o.units, o.observation_datetime
                    FROM observations o
                    JOIN patients_decrypted pd ON pd.patient_id = o.patient_id
                    WHERE o.observation_datetime >= current_date - interval '7 days'
                """)
                results.append(("Recent Observations", headers, data))
                if show_perf and perf:
                    results.append(("Performance Report", ["Metric", "Value"], perf))

            elif action == 'search_patient':
                if not (search_first or search_last or search_dob):
                    error = "Please enter at least one search criteria (first name, last name, or date of birth)."
                else:
                    query_str = "SELECT patient_id, first_name, last_name, date_of_birth, gender, phone_number, address, city, state, zip_code FROM patients_decrypted WHERE TRUE"
                    params = []
                    if search_first:
                        query_str += " AND first_name ILIKE %s"
                        params.append(f"%{search_first}%")
                    if search_last:
                        query_str += " AND last_name ILIKE %s"
                        params.append(f"%{search_last}%")
                    if search_dob:
                        query_str += " AND date_of_birth = %s"
                        params.append(search_dob)

                    data, headers, perf = execute(query_str, tuple(params))
                    results.append(("Patient Info", headers, data))
                    if show_perf and perf:
                        results.append(("Performance Report", ["Metric", "Value"], perf))

                    if data:
                        patient_id = data[0][0]

                        def add_section(title, sql, params=(patient_id,)):
                            d, h, p = execute(sql, params)
                            results.append((title, h, d))
                            if show_perf and p:
                                results.append(("Performance Report", ["Metric", "Value"], p))

                        add_section("Diagnoses", "SELECT * FROM diagnoses WHERE patient_id = %s")
                        add_section("Medications", "SELECT * FROM medications WHERE patient_id = %s")
                        add_section("Procedures", "SELECT * FROM procedures WHERE patient_id = %s")
                        add_section("Observations", "SELECT * FROM observations WHERE patient_id = %s")
                        add_section("Encounters", "SELECT * FROM encounters WHERE patient_id = %s")
            
            elif action == 'age_stats':
                data, headers, perf = execute("""
                    SELECT
                        ROUND(AVG(EXTRACT(YEAR FROM AGE(current_date, date_of_birth))), 2) AS average_age,
                        MIN(EXTRACT(YEAR FROM AGE(current_date, date_of_birth))) AS min_age,
                        MAX(EXTRACT(YEAR FROM AGE(current_date, date_of_birth))) AS max_age
                    FROM patients_decrypted
                    WHERE date_of_birth IS NOT NULL
                """)
                results.append(("Average Age and Age Range", headers, data))
                if show_perf and perf:
                    results.append(("Performance Report", ["Metric", "Value"], perf))


            elif action == 'avg_patients_per_physician':
                data, headers, perf = execute("""
                    SELECT ROUND(AVG(patient_count), 2) AS avg_patients_per_physician
                    FROM (
                        SELECT attending_physician_id, COUNT(DISTINCT patient_id) AS patient_count
                        FROM encounters
                        WHERE attending_physician_id IS NOT NULL
                        GROUP BY attending_physician_id
                    ) sub;
                """)
                results.append(("Average Patients per Physician", headers, data))
                if show_perf and perf:
                    results.append(("Performance Report", ["Metric", "Value"], perf))





            elif action == 'custom_query':
                if not query.lower().startswith('select'):
                    error = "Only SELECT queries are allowed."
                else:
                    data, headers, perf = execute(query)
                    results.append(("Custom Query", headers, data))
                    if show_perf and perf:
                        results.append(("Performance Report", ["Metric", "Value"], perf))

            elif action == 'noop':
                # For perf checkbox toggle
                pass

            cur.close()
            conn.close()

        except Exception as e:
            error = str(e)

    return render_template_string(DASHBOARD_TEMPLATE, results=results, query=query, error=error, show_perf=show_perf)

@app.route('/logout', methods=['POST'])
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(port=5000)
