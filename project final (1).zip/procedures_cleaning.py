import pandas as pd
import psycopg2

csv_path = r"D:\Assignments\Data Engineering\project\data\procedures.csv"
df = pd.read_csv(csv_path)
df.columns = df.columns.str.strip()

print(f" Total rows loaded from CSV: {len(df)}")

def clean_datetime(dt):
    try:
        # ISO 8601
        parsed = pd.to_datetime(dt, format='%Y-%m-%dT%H:%M:%S.%f', errors='coerce')
        if pd.isna(parsed):
            parsed = pd.to_datetime(dt, format='%Y-%m-%dT%H:%M:%S', errors='coerce')
        return parsed.floor('s') if not pd.isna(parsed) else pd.NaT
    except:
        return pd.NaT

df['date_performed'] = df['date_performed'].apply(clean_datetime)

invalid_dates = df[df['date_performed'].isna()]
if not invalid_dates.empty:
    print("Skipping rows with invalid 'date_performed':")
    print(invalid_dates[['procedure_id', 'date_performed']])
df = df.dropna(subset=['date_performed'])

print(f" Rows after date cleaning: {len(df)}")

conn = psycopg2.connect(
    host="localhost",
    port="5432",
    dbname="postgres",
    user="postgres",
    password="1234"
)
cur = conn.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS procedures (
    date_performed TIMESTAMP,
    encounter_id UUID,
    patient_id UUID,
    procedure_code TEXT,
    procedure_description TEXT,
    procedure_id UUID PRIMARY KEY
);
""")
conn.commit()

inserted = 0
for _, row in df.iterrows():
    try:
        cur.execute("""
            INSERT INTO procedures (
                date_performed, encounter_id, patient_id, procedure_code,
                procedure_description, procedure_id
            ) VALUES (%s, %s, %s, %s, %s, %s)
            ON CONFLICT (procedure_id) DO NOTHING;
        """, (
            row['date_performed'], row['encounter_id'], row['patient_id'],
            row['procedure_code'], row['procedure_description'], row['procedure_id']
        ))
        inserted += 1
    except Exception as e:
        print(f"Error inserting row with procedure_id={row['procedure_id']}: {e}")

conn.commit()
cur.close()
conn.close()

print(f"Inserted {inserted} rows into 'procedures' table.")
