import json
import pandas as pd
import psycopg2


JSON_PATH = r"D:\Assignments\Data Engineering\project\data\medications.json"
DB_CONFIG = {
    "host":     "localhost",
    "port":     "5432",
    "dbname":   "postgres",
    "user":     "postgres",
    "password": "1234"
}


with open(JSON_PATH, 'r', encoding='utf-8') as f:
    data = json.load(f)

df = pd.json_normalize(data)

print(f"Total records in JSON: {len(df)}")


df['start_date'] = pd.to_datetime(df['start_date'], format='%Y-%m-%d', errors='coerce').dt.date
df['end_date']   = pd.to_datetime(df['end_date'],   format='%Y-%m-%d', errors='coerce').dt.date


bad_start = df['start_date'].isna().sum()
bad_end   = df['end_date'].isna().sum() - df['end_date'].isna().sum()  # allow null end dates
if bad_start:
    print(f"Found {bad_start} records with invalid/missing start_date (they’ll be dropped)")
    df = df.dropna(subset=['start_date'])

print(f"Records after date parsing: {len(df)}")


conn = psycopg2.connect(**DB_CONFIG)
cur = conn.cursor()


cur.execute("""
CREATE TABLE IF NOT EXISTS medications (
    medication_order_id UUID PRIMARY KEY,
    patient_id           UUID,
    encounter_id         UUID,
    drug_code            TEXT,
    drug_name            TEXT,
    dosage               TEXT,
    route                TEXT,
    frequency            TEXT,
    start_date           DATE,
    end_date             DATE
);
""")
conn.commit()


inserted = 0
for _, row in df.iterrows():
    cur.execute("""
        INSERT INTO medications (
            medication_order_id,
            patient_id,
            encounter_id,
            drug_code,
            drug_name,
            dosage,
            route,
            frequency,
            start_date,
            end_date
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (medication_order_id) DO NOTHING;
    """, (
        row['medication_order_id'],
        row['patient_id'],
        row['encounter_id'],
        row['drug_code'],
        row['drug_name'],
        row['dosage'],
        row['route'],
        row['frequency'],
        row['start_date'],
        row['end_date'] if pd.notna(row['end_date']) else None
    ))
    inserted += 1

conn.commit()
cur.close()
conn.close()

print(f"Inserted {inserted} rows into medications.")
